package rise.smarthome.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import rise.smarthome.arduino.ArduinoControl;
import rise.smarthome.featureModeling.FeatureBase;
import rise.smarthome.features.AutomatedIluminationByLuminosity;
import rise.smarthome.features.AutomatedIluminationByPresence;
import rise.smarthome.features.UserIlumination;
import rise.smarthome.featuresUI.AutomatedIluminationByLuminosityUI;
import rise.smarthome.featuresUI.AutomatedIluminationByPresenceUI;
import rise.smarthome.featuresUI.FeatureUIBase;
import rise.smarthome.featuresUI.UserIluminationUI;
import rise.smarthome.model.home.HouseFacade;

public class Main extends JFrame {

	private static final long serialVersionUID = -5521585541646467250L;
	private static HouseFacade house;
	private static JPanel contentPane;
	private static JTabbedPane tabbedPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArduinoControl.getInstance();
					house = new HouseFacade();
					Main frame = new Main();
					updateFeaturesTabs();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void updateFeaturesTabs(){
		for (FeatureBase feature : HouseFacade.getFeatures()) {
			
			if(feature instanceof UserIlumination){
				boolean alreadyExist = false;
				for (int i = 0; i < tabbedPane.getTabCount(); i++) {
					if(tabbedPane.getComponentAt(i) instanceof FeatureUIBase){
						FeatureUIBase featureTab = (FeatureUIBase) tabbedPane.getComponentAt(i);
						if(featureTab.isForClass(UserIlumination.class)){
							alreadyExist = true;
							break;
						}
					}
				}
				if(!alreadyExist){
					UserIluminationUI userIluminationUI = new UserIluminationUI();
					tabbedPane.addTab("User Ilumination", null, userIluminationUI);
				}
			}
			
			if(feature instanceof AutomatedIluminationByLuminosity){
				boolean alreadyExist = false;
				for (int i = 0; i < tabbedPane.getTabCount(); i++) {
					if(tabbedPane.getComponentAt(i) instanceof FeatureUIBase){
						FeatureUIBase featureTab = (FeatureUIBase) tabbedPane.getComponentAt(i);
						if(featureTab.isForClass(AutomatedIluminationByLuminosity.class)){
							alreadyExist = true;
							break;
						}
					}
				}
				if(!alreadyExist){
					AutomatedIluminationByLuminosityUI automatedIluminationByLuminosityUI = new AutomatedIluminationByLuminosityUI();
					tabbedPane.addTab("Automated Ilumumination by Luminosity", null, automatedIluminationByLuminosityUI);
				}
			}
			
			if(feature instanceof AutomatedIluminationByPresence){
				boolean alreadyExist = false;
				for (int i = 0; i < tabbedPane.getTabCount(); i++) {
					if(tabbedPane.getComponentAt(i) instanceof FeatureUIBase){
						FeatureUIBase featureTab = (FeatureUIBase) tabbedPane.getComponentAt(i);
						if(featureTab.isForClass(AutomatedIluminationByPresence.class)){
							alreadyExist = true;
							break;
						}
					}
				}
				if(!alreadyExist){
					AutomatedIluminationByPresenceUI automatedIluminationByPresenceUI = new AutomatedIluminationByPresenceUI();
					tabbedPane.addTab("Automated Ilumumination by Presence", null, automatedIluminationByPresenceUI);
				}
			}
			//
         	
		}
	}

	public static HouseFacade getHouseInstance(){
		return house;
	}
	public Main() {
		setTitle("RiSE SmartHome - Mission Control");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 470, 349);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 466, 325);
		FeatureControlTab generalTab = new FeatureControlTab();
		tabbedPane.addTab("Feature Control", null, generalTab);
		HardwareControlTab hardwareControlTab = new HardwareControlTab();
		tabbedPane.addTab("Hardware Control", null, hardwareControlTab);
		contentPane.add(tabbedPane);

	}

	public static void removeFeatureTab(Class<? extends FeatureBase> clazz) {
		
            if(clazz.equals(AutomatedIluminationByLuminosity.class)){
			for (int i = 0; i < tabbedPane.getTabCount(); i++) {
				if(tabbedPane.getComponentAt(i) instanceof FeatureUIBase){
					FeatureUIBase featureTab = (FeatureUIBase) tabbedPane.getComponentAt(i);
					if(featureTab.isForClass(AutomatedIluminationByLuminosity.class)){
						tabbedPane.removeTabAt(i);
					}
				}
			}
		}
	
		
	
		
		if(clazz.equals(AutomatedIluminationByPresence.class)){
			for (int i = 0; i < tabbedPane.getTabCount(); i++) {
				if(tabbedPane.getComponentAt(i) instanceof FeatureUIBase){
					FeatureUIBase featureTab = (FeatureUIBase) tabbedPane.getComponentAt(i);
					if(featureTab.isForClass(AutomatedIluminationByPresence.class)){
						tabbedPane.removeTabAt(i);
					}
				}
			}
		}
		
 	
	}
}
