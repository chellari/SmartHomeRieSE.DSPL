package rise.smarthome.model.home;

import java.lang.annotation.Annotation;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import rise.smarthome.featureModeling.FeatureBase;
import rise.smarthome.features.PresenceIlusion;
import rise.smarthome.features.UserIlumination;
import rise.smarthome.model.devices.Hardware;
import rise.smarthome.model.devices.Led;


public class HouseFacade {
	private static ArrayList<FeatureBase> avaliableFeatures;
	private static ArrayList<FeatureBase> features;
	private static ArrayList<Hardware> hardwareList;
	private static AutomatedFeaturesRunnable automatedFeaturesRunnable;

	public HouseFacade(){
		features = new ArrayList<FeatureBase>();
		hardwareList = new ArrayList<Hardware>();
	}

	public void addAvaliableFeature(FeatureBase featureBase){
		avaliableFeatures.add(featureBase);
	}
	
	public static void loadAvaliableFeatures() {
		avaliableFeatures = new ArrayList<FeatureBase>();
	}


	public FeatureBase getFeatureByType(Class<? extends FeatureBase> clazz){
		for (FeatureBase feature : features) {
			if(clazz.isInstance(feature)){
				return feature;
			}
		}
		return null;
	}

	public ArrayList<Hardware> getAllHardwareByType(Class<? extends Hardware> clazz){
		ArrayList<Hardware> hardwareList = new ArrayList<Hardware>();
		for (Hardware hardware : hardwareList) {
			if(clazz.isInstance(hardware)){
				hardwareList.add(hardware);
			}
		}
		return hardwareList;
	}


	public static void loadMandatoryFeatures() {
		UserIlumination userIlumination = UserIlumination.getInstance(new ArrayList<Led>());
		features.add(userIlumination);
		PresenceIlusion presenceIlusion = PresenceIlusion.getInstance(userIlumination);
		features.add(presenceIlusion);
	}
  

	public static Hardware findHardware(int pin, boolean isAnalog) {
		for (Hardware hardware : hardwareList) {
			if(hardware.getPin() == pin && hardware.isAnalog() == isAnalog)
				return hardware;
		}
		return null;
	}
	
	public void removeHardware(int pin, boolean isAnalog){
		Hardware anyHardware = findHardware(pin,isAnalog);
		if(hardwareList.contains(anyHardware)){
			hardwareList.remove(anyHardware);
			JOptionPane.showMessageDialog(null, "Hardware removed successfully!","RiSE SmartHome - INFO",JOptionPane.INFORMATION_MESSAGE);
		}else{
			JOptionPane.showMessageDialog(null, "No have any hardware installed in this pin","RiSE SmartHome - INFO",JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void addHardware(Hardware newHardware){
		if (hardwareList.contains(newHardware)){
			JOptionPane.showMessageDialog(null, "Already exists another hardware installed in this pin.\n "
					+ "The action cannot be completed","RiSE SmartHome - INFO",JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		hardwareList.add(newHardware);
		JOptionPane.showMessageDialog(null, "Hardware successfully added!","RiSE SmartHome - INFO",JOptionPane.INFORMATION_MESSAGE);

	}	

	private boolean evaluateForFeatureDependency(FeatureBase feature) {
		// if the feature is child of another feature this always can be deleted
		if(!feature.getClass().getSuperclass().equals(FeatureBase.class))
			return true;
		for (FeatureBase featureBase : features) {
			for (FeatureBase requiredFeature : featureBase.getRequiredFeatures()) {
				if(feature == requiredFeature)
					return false;
			}
		}
		return true;
	}


	public  void addFeature(FeatureBase newFeature){
		
	}

	@SuppressWarnings("unused")
	private boolean evaluateForFeatureRepetition(FeatureBase newFeature) {
		for (FeatureBase featureBase : features) {
			if(featureBase.equals(newFeature))
				return false;
		}
		return true;
	}

	public void removeFeature(FeatureBase feature){
		if(evaluateForFeatureDependency(feature)){
			resolveRemotionFeatureHierarchy(feature);
		}else{
			JOptionPane.showMessageDialog(null, "The selected feature cannot be removed. Some other features require them");
		}
	}
	private void resolveRemotionFeatureHierarchy(FeatureBase feature) {
		Class<? extends FeatureBase> featureClass = feature.getClass();
		//if(featureClass.getSuperclass().equals(FeatureBase.class))
		//return;
		// Alternative Features have abstract superclass, so always can be deleted
		if(Modifier.isAbstract(featureClass.getSuperclass().getModifiers())){
			features.remove(feature);
		}
		// search for a feature brother
		for (FeatureBase featureBase : features) {
			// A feature brother will be different and has the same super class of the feature to be removed
			if(!featureBase.getClass().equals(featureClass) && featureBase.getClass().getSuperclass().equals(featureClass.getSuperclass())){
				// If the feature to remove has a brother, we need to exchange all features that require them to your brother
				exchangeRequiredFeature(feature, featureBase);
				features.remove(feature);
				return;
			}
		}
	}

	@SuppressWarnings("unused")
	private  boolean evaluationForFeatureHierarchy(FeatureBase newFeature){
		for (FeatureBase featureBase : features) {
			// If exist any father feature of the new feature added
			if(newFeature.getClass().getSuperclass().equals(featureBase.getClass())){
				keepFeatureState(featureBase,newFeature);
				exchangeRequiredFeature(featureBase,newFeature);
				features.remove(featureBase);
				return true;
			}
			//If the new feature is brother of a feature previously added. 
			if(featureBase.getClass().getSuperclass().equals(newFeature.getClass().getSuperclass())){
				exchangeBrotherFeaturesData(featureBase,newFeature);
				return true;
			}
			// If the new feature is super class of an already added feature so, do nothing
			if(featureBase.getClass().getSuperclass().equals(newFeature.getClass())){
				return false;
			}
		}
		return true;
	}

	private void exchangeBrotherFeaturesData(FeatureBase featureBase,FeatureBase newFeature) {
		
               
		
	}


	private void keepFeatureState(FeatureBase oldFeature, FeatureBase newFeature) {
		
	}

	public static void exchangeRequiredFeature(FeatureBase oldFeature, FeatureBase newFeature){
		for (FeatureBase featureBase : features) {
			if(featureBase.getRequiredFeatures() !=null && !featureBase.getRequiredFeatures().isEmpty()){
				for (int i = 0; i < featureBase.getRequiredFeatures().size(); i++) {
					if(featureBase.getRequiredFeatures().get(i) == oldFeature){
						featureBase.getRequiredFeatures().set(i, newFeature);
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	public <A extends Annotation> A[] getAnnotationsByType(Class<? extends FeatureBase> featureClass,
			Class<? extends Annotation> requestedAnnotation){
		ArrayList<Annotation> annotations = new ArrayList<Annotation>();
		for (Annotation annotation : featureClass.getAnnotations()) {
			if(annotation.annotationType().equals(requestedAnnotation)){
				annotations.add(annotation);
			}
		}
		return ((A[])annotations.toArray());
	}

	


	public static ArrayList<FeatureBase> getFeatures() {
		return features;
	}

	public void setFeatures(ArrayList<FeatureBase> features) {
		HouseFacade.features = features;
	}

	public ArrayList<Hardware> getHardwareList() {
		return hardwareList;
	}

	public void setHardwareList(ArrayList<Hardware> hardwareList) {
		HouseFacade.hardwareList = hardwareList;
	}

	public ArrayList<FeatureBase> getAvaliableFeatures() {
		ArrayList<FeatureBase> avalFeature = new ArrayList<FeatureBase>();
		avalFeature.addAll(avaliableFeatures);
		avalFeature.removeAll(features);
		return avalFeature;
	}

	public static AutomatedFeaturesRunnable getAutomatedFeaturesRunnable() {
		return automatedFeaturesRunnable;
	}

	public static void setAutomatedFeaturesRunnable(
			AutomatedFeaturesRunnable automatedFeaturesRunnable) {
		HouseFacade.automatedFeaturesRunnable = automatedFeaturesRunnable;
	}
}
