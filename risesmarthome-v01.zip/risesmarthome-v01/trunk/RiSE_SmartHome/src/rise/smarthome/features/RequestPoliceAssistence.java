package rise.smarthome.features;

import rise.smarthome.featureModeling.FeatureBase;

public class RequestPoliceAssistence extends FeatureBase {

	private static RequestPoliceAssistence requestPoliceAssistence = null;
	
	protected RequestPoliceAssistence(){}
	
	public static RequestPoliceAssistence getInstance() {
		if(requestPoliceAssistence == null){
			requestPoliceAssistence = new RequestPoliceAssistence();
			requestPoliceAssistence.setName("Request Police Assistence");
		}
		return requestPoliceAssistence;
	}
	
	public static void distroy() {
		requestPoliceAssistence = null;
	}

	@Override
	public void proceedActions(String[] args) {
		// TODO Auto-generated method stub

	}

}
