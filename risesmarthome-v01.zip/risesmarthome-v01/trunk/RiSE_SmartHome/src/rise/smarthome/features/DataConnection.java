package rise.smarthome.features;

import rise.smarthome.featureModeling.FeatureBase;

public abstract class DataConnection extends FeatureBase {

}
