package rise.smarthome.features;

import rise.smarthome.featureModeling.FeatureBase;

public class NotifyByVoipCall extends FeatureBase {

	private static NotifyByVoipCall notifyByVoipCall = null;
	
	protected NotifyByVoipCall(){}
	
	public static NotifyByVoipCall getInstance() {
		if(notifyByVoipCall == null){
			notifyByVoipCall = new NotifyByVoipCall();
			notifyByVoipCall.setName("Notify By VoIP call");
		}
		return notifyByVoipCall;
	}
	
	public static void distroy() {
		notifyByVoipCall = null;
	}
	@Override
	public void proceedActions(String[] args) {
		
	}

}
