package rise.smarthome.features;

import rise.smarthome.featureModeling.AlternativeFeature;

@AlternativeFeature(alternatives={WifiDataConnection.class})
public class MobileNetworkDataConnection extends DataConnection {

	private static MobileNetworkDataConnection mobileNetworkDataConnection = null;
	
	protected MobileNetworkDataConnection(){}
	
	public static MobileNetworkDataConnection getInstance() {
		if(mobileNetworkDataConnection == null){
			mobileNetworkDataConnection = new MobileNetworkDataConnection();
			mobileNetworkDataConnection.setName("Mobile Network Data Connection");
		}
		return mobileNetworkDataConnection;
	}
	
	public static void distroy() {
		mobileNetworkDataConnection = null;
	}

	@Override
	public void proceedActions(String[] args) {
		// TODO Auto-generated method stub

	}

}
