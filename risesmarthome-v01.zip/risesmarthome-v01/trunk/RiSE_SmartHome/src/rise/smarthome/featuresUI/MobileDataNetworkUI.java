package rise.smarthome.featuresUI;
import java.awt.Color;

import javax.swing.JLabel;

import rise.smarthome.features.MobileNetworkDataConnection;
import rise.smarthome.gui.Main;

public class MobileDataNetworkUI extends FeatureUIBase {
	
	private static final long serialVersionUID = 5575292698449566428L;
	private MobileNetworkDataConnection mobileNetworkDataConnection;
	
	public MobileDataNetworkUI() {
		mobileNetworkDataConnection = (MobileNetworkDataConnection) Main.getHouseInstance().getFeatureByType(MobileNetworkDataConnection.class);
		setForClass(MobileNetworkDataConnection.class);
		JLabel lblMobileDataNetwork = new JLabel("Mobile Data Network Feature can't start. Hardware not connected");
		lblMobileDataNetwork.setForeground(Color.RED);
		lblMobileDataNetwork.setBounds(16, 142, 418, 16);
		add(lblMobileDataNetwork);
	}

}
