package rise.smarthome.featureModeling;

public interface AdaptableFeature {
	void proceedActions();
}
