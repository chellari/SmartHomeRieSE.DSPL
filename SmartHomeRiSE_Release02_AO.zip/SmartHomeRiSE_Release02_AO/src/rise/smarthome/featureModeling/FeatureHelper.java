package rise.smarthome.featureModeling;

import java.util.ArrayList;
import java.util.List;

//#if defined(alarm_against_robery)
import rise.smarthome.features.AlarmAgainstRobbery;
//#endif

//#if defined(panic_mode)
import rise.smarthome.features.PanicMode;
//#endif
//#if defined(presence_ilusion)
import rise.smarthome.features.PresenceIlusion;
//#endif


//#if defined(user_ilumination)
import rise.smarthome.features.UserIlumination;
//#endif

public class FeatureHelper {

	public static List<Class<? extends FeatureBase>> getAllAvaliableFeatures(){

		ArrayList<Class<? extends FeatureBase>> featureList = new ArrayList<Class<? extends FeatureBase>>();

		//#if defined(alarm_against_robery)
		featureList.add(AlarmAgainstRobbery.class);
		//#endif

		//#if defined(panic_mode)
		featureList.add(PanicMode.class);
		//#endif

		//#if defined(presence_ilusion)
		featureList.add(PresenceIlusion.class);
		//#endif

		//#if defined(user_ilumination)
		featureList.add(UserIlumination.class);
		//#endif

		return featureList;
	}
}
