package rise.smarthome.model.devices;

public class AirConditioner extends Actuator {

	public AirConditioner(int pin, boolean isAnalog) {
		super(pin, isAnalog,"Air Conditioner");
 	}

}
