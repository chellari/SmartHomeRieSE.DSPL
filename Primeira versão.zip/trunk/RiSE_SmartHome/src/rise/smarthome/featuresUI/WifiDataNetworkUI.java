package rise.smarthome.featuresUI;
import java.awt.Color;

import javax.swing.JLabel;

import rise.smarthome.features.WifiDataConnection;
import rise.smarthome.gui.Main;

public class WifiDataNetworkUI extends FeatureUIBase {
	
	private static final long serialVersionUID = 5575292698449566428L;
	private WifiDataConnection wifiDataConnection;
	
	public WifiDataNetworkUI() {
		wifiDataConnection = (WifiDataConnection) Main.getHouseInstance().getFeatureByType(WifiDataConnection.class);
		setForClass(WifiDataConnection.class);
		JLabel lblMobileDataNetwork = new JLabel("WiFi Data Network Feature can't start. Hardware not connected");
		lblMobileDataNetwork.setForeground(Color.RED);
		lblMobileDataNetwork.setBounds(16, 142, 418, 16);
		add(lblMobileDataNetwork);
	}

}
