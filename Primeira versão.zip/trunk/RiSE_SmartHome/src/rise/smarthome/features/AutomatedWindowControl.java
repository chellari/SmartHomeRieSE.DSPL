package rise.smarthome.features;

import rise.smarthome.featureModeling.AdaptableFeature;
import rise.smarthome.model.devices.AutomaticWindow;
import rise.smarthome.model.devices.TemperatureSensor;
import rise.smarthome.util.ListUtils;

public class AutomatedWindowControl extends UserWindowControl implements AdaptableFeature{

	private TemperatureSensor temperatureSensor;
	private int[] windowsToAutomate;

	private static AutomatedWindowControl automatedWindowControl = null;
	
	protected AutomatedWindowControl(){}
	
	public static AutomatedWindowControl getInstance() {
		if(automatedWindowControl == null){
			automatedWindowControl = new AutomatedWindowControl();
			automatedWindowControl.setName("Automated Window Control");
		}
		return automatedWindowControl;
	}
	
	public static void distroy() {
		automatedWindowControl = null;
	}
	@Override
	public void proceedActions() {
		for (AutomaticWindow automaticWindow : getAutomaticWindows()) {
			if(windowsToAutomate != null){
				if(ListUtils.isInRange(windowsToAutomate, automaticWindow.getPin())) temperatureSensor.act(automaticWindow);
			}else{
				temperatureSensor.act(automaticWindow);
			}
		}
	}

}
