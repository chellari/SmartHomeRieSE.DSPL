package rise.smarthome.features;

import rise.smarthome.featureModeling.AlternativeFeature;

@AlternativeFeature(alternatives={MobileNetworkDataConnection.class})
public class WifiDataConnection extends DataConnection {

	private static WifiDataConnection wifiDataConnection = null;
	
	protected WifiDataConnection(){}
	
	public static WifiDataConnection getInstance() {
		if(wifiDataConnection == null){
			wifiDataConnection = new WifiDataConnection();
			wifiDataConnection.setName("WiFi Data Connection");
		}
		return wifiDataConnection;
	}
	
	public static void distroy() {
		wifiDataConnection = null;
	}

	@Override
	public void proceedActions(String[] args) {
		// TODO Auto-generated method stub

	}

}
