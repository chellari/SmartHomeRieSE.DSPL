package rise.smarthome.features;

import rise.smarthome.featureModeling.FeatureBase;

public class RequestNeighborAssistence extends FeatureBase {

	private static RequestNeighborAssistence requestNeighborAssistence = null;
	
	protected RequestNeighborAssistence(){}
	
	public static RequestNeighborAssistence getInstance() {
		if(requestNeighborAssistence == null){
			requestNeighborAssistence = new RequestNeighborAssistence();
			requestNeighborAssistence.setName("Request Neighbor Assistence");
		}
		return requestNeighborAssistence;
	}
	
	public static void distroy() {
		requestNeighborAssistence = null;
	}

	@Override
	public void proceedActions(String[] args) {
		
	}

}
