package rise.smarthome.features;

import rise.smarthome.featureModeling.FeatureBase;

public class NotifyByEmail extends FeatureBase {

	private static NotifyByEmail notifyByEmail = null;
	
	protected NotifyByEmail(){}
	
	public static NotifyByEmail getInstance() {
		if(notifyByEmail == null){
			notifyByEmail = new NotifyByEmail();
			notifyByEmail.setName("Notify By Email");
		}
		return notifyByEmail;
	}
	
	public static void distroy() {
		notifyByEmail = null;
	}
	@Override
	public void proceedActions(String[] args) {
		// TODO Auto-generated method stub

	}

}
