package rise.smarthome.features;

import rise.smarthome.featureModeling.AdaptableFeature;
import rise.smarthome.model.devices.AirConditioner;
import rise.smarthome.model.devices.TemperatureSensor;
import rise.smarthome.util.ListUtils;

public class AutomatedAirConditionerControl extends UserAirConditionerControl implements AdaptableFeature{

	private TemperatureSensor temperatureSensor;
	private int[] airConditionersToAutomate;

	private static AutomatedAirConditionerControl automatedAirConditionerControl = null;
	
	protected AutomatedAirConditionerControl(){}
	
	public static AutomatedAirConditionerControl getInstance() {
		if(automatedAirConditionerControl == null){
			automatedAirConditionerControl = new AutomatedAirConditionerControl();
			automatedAirConditionerControl.setName("Automated Air Conditioner Control");
		}
		return automatedAirConditionerControl;
	}
	
	public static void distroy() {
		automatedAirConditionerControl = null;
	}
	@Override
	public void proceedActions() {
		for (AirConditioner airConditioner : getAirConditioners()) {
			if(airConditionersToAutomate != null){
				if(ListUtils.isInRange(airConditionersToAutomate, airConditioner.getPin())) temperatureSensor.act(airConditioner);
			}else{
				temperatureSensor.act(airConditioner);
			}
		}
	}

}
